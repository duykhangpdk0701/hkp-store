<?php

namespace App\Repositories\ItemStockPrice;

use App\Repositories\RepositoryInterface;

/**
 * The repository interface for the Item Stock Price Model
 */
interface ItemStockPriceRepositoryInterface extends RepositoryInterface
{
}
