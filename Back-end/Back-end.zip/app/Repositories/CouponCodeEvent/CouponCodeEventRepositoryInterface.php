<?php

namespace App\Repositories\CouponCodeEvent;

use App\Repositories\RepositoryInterface;

/**
 * The repository interface for the Coupon Code Model
 */
interface CouponCodeEventRepositoryInterface extends RepositoryInterface
{
}
